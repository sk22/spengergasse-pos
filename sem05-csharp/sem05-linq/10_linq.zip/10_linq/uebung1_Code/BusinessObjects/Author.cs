using System;
using System.Collections.Generic;
using System.Text;

namespace LinqInAction.LinqBooks.Common
{
  public class Author
  {
    public String FirstName {get; set;}
    public String LastName {get; set;}
    public String WebSite { get; set;}
  }
}