﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqInAction.LinqBooks.Common
{
  public class User
  {
    public String Name {get; set;}
  }
}
