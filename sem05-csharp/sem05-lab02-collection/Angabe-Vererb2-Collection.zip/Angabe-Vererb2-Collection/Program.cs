﻿using System;
using System.Collections;
using System.Text;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Employee emp2 = new Employee();
            WageEmployee wemp2 = new WageEmployee("Fred");
            SalesPerson semp2 = new SalesPerson("Wilma");
            Manager man2 = new Manager("Boss");

            Console.WriteLine(emp2);

            Console.WriteLine(emp2.Name + " verdient " + emp2.computePay());
            wemp2.Wage = 224;
            wemp2.Hours = 24;
            Console.WriteLine(wemp2.Name + " verdient " + wemp2.computePay());
            semp2.Salesmade = (1234);
            semp2.Commission = (0.3);
            semp2.Wage = (224);
            semp2.Hours = (24);
            Console.WriteLine(semp2.Name + " verdient " + semp2.computePay());
            man2.Weeklysalary =((float)2500.5);
            Console.WriteLine(man2.Name + " verdient " + man2.computePay());

        }
    }

  
}
