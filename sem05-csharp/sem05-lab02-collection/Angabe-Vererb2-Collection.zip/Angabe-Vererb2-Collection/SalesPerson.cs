﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication4
{
    class SalesPerson : WageEmployee
    {


        // zusätzliche Attribute um Verkaufsdaten zu speichern
        private double commission;
        private double salesmade;

 

        // Konstruktoren
        public SalesPerson(String n) : base (n)
        {
            //super(n); // gib n an der Parentklassenkonstruktor weiter
            //System.out.println ("bin im SalesPersonkonstruktor Param " + n);
            commission = 0;
            salesmade = 0;
        }
        public SalesPerson()
        {
            commission = 0;
            salesmade = 0;
            //System.out.println ("bin im SalesPersonkonstruktor Param " + n);
        }


        public double Commission
        {
            get { return commission; }
            set { commission = value; }
        }
        public double Salesmade
        {
            get { return salesmade; }
            set { salesmade = value; }
        }
        public String toString()
        {
            return Name + " ist ein Salesp";
        }

        public override  float computePay()
        {
            return (float)(commission * salesmade + base.computePay());
        }

    }
}
