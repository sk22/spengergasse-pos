using System;

namespace ConsoleApplication4
{
    public class Employee  
    {
        // Attribute um Angestelltendaten zu speichern
        private String name;

        // Konstruktoren
        public Employee()
        {
            name = "Hugo";
            // System.out.println ("bin im Employeekonstruktor");
        }
        public Employee(String n)
        {
            name = n;
            //System.out.println ("bin im Employeekonstruktor Param " + n);
        }


        public String Name
        {
            get { return name; }
            set { name = value; }
        }
        
        public override String ToString()  
        {
            return "Employee: " + name;
        }

        public  virtual float computePay()
        {
            return 0;
        }
    }
}

