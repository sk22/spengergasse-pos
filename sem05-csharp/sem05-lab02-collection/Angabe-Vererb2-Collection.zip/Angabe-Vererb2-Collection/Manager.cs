
using System;

namespace ConsoleApplication4
{

public class Manager : Employee
{
	// Attribute um Angestelltendaten zu speichern
    private float weeklysalary;



           		// Konstruktoren
   public Manager(String n) : base (n)
  {
  	 //super(n); // gib n an der Parentklassenkonstruktor weiter
        //System.out.println ("bin im Manager Param " + n);
    weeklysalary = 0;
  }

   public Manager()
  {
    weeklysalary = 0;
        //System.out.println ("bin im Managerkonstruktor " );
  }

   public float Weeklysalary
   {
       get { return weeklysalary; }
       set { weeklysalary = value; }
   }


  public override float computePay()
  {
    return weeklysalary;
  }


}


}