﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication4
{
    class WageEmployee : Employee 
    {

        // Attribute um Angestelltendaten zu speichern
        private float wage;
        private float hours;



        // Konstruktoren

        public WageEmployee(String n) : base (n)
        {
            //super(n); // gib n an der Parentklassenkonstruktor weiter
            //System.out.println ("bin im WageEmployeekonstruktor Param " + n);
            wage = 0;
            hours = 0;
        }

        public WageEmployee()
        {
            wage = 0;
            hours = 0;
            //System.out.println ("bin im WageEmployeekonstruktor " );
        }


        public float Wage
        {
            get { return wage; }
            set { wage = value; }
        }
        public float Hours
        {
            get { return hours; }
            set { hours = value; }
        }

        public override  float computePay()
        {
            return wage * hours;
        }



    }
}
