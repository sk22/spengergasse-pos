namespace Spengergasse.ConsoleWeatherApp {
  internal interface IView {
    void Show();
  }
}