package at.spengergasse.kai17521.lab06map;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toolbar;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;


public class MainActivity extends AppCompatActivity {
  MapView map = null;
  MyLocationNewOverlay mLocationOverlay = null;
  final int PERMISSIONS_LOCATION = 1;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    //handle permissions first, before map is created. not depicted here

    //load/initialize the osmdroid configuration, this can be done
    Context ctx = getApplicationContext();
    Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

    setContentView(R.layout.activity_main);

    requestPermissions();

    map = findViewById(R.id.map);
    map.setTileSource(TileSourceFactory.MAPNIK);

    Toolbar myToolbar = (Toolbar) findViewById(R.id.map_toolbar);
    setSupportActionBar(myToolbar);


    // TODO:
    // - Request permissions for own position
    // - Add menu to choose categories
    // - Add POIs (points of interest) to map
    // - Add overlay for POI details (display name and address)
  }

  private void requestPermissions() {
    final int permissionAccessFineLocation = ContextCompat
      .checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
    final int permissionAccessNetworkState = ContextCompat
      .checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE);
    final int permissionInternet = ContextCompat
      .checkSelfPermission(this, Manifest.permission.INTERNET);

    if (permissionAccessFineLocation != PERMISSION_GRANTED ||
        permissionAccessNetworkState != PERMISSION_GRANTED ||
        permissionInternet != PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(this, new String[] {
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.INTERNET
      }, PERMISSIONS_LOCATION);
    }
  }

  private void onClickLocate() {
    if (mLocationOverlay == null) {
      this.mLocationOverlay = new MyLocationNewOverlay(
        new GpsMyLocationProvider(getApplicationContext()), map);
      map.getOverlays().add(this.mLocationOverlay);
    }
    this.mLocationOverlay.enableMyLocation();
  }
}
