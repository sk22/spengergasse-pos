package at.spengergasse.kai17521.sem03.lab05;

/**
 * @author Samuel Kaiser
 * @since 10/17/2016
 */
abstract class AbstractBuilder<T> {
  public abstract T build(int id);
}
