package at.spengergasse.kai17521.sem04.lab20.model;

/**
 * @author Samuel Kaiser
 * @since 4/3/2017
 */
public enum State {
  HIDDEN,
  ACTIVE,
  VISIBLE;
}
